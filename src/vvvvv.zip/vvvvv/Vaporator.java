package vvvvv;
import battlecode.common.*;

public strictfp class Vaporator extends RobotPlayer {
    
    static void runVaporator() throws GameActionException {
    
    }
    
}