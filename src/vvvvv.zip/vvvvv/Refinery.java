package vvvvv;
import battlecode.common.*;

public strictfp class Refinery extends RobotPlayer {
    
    static void runRefinery() throws GameActionException {
        // System.out.println("Pollution: " + rc.sensePollution(rc.getLocation()));
    }
    
}